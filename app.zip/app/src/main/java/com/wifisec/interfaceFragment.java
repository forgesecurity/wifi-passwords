package com.wifisec;
import android.net.Uri;

public class interfaceFragment {

    public interface OnFragmentInteractionListener {
        public void onFragmentInteraction(Uri uri);
    }
}
